package com.vessel.velocity.mixin;

import io.netty.channel.Channel;
import io.netty.channel.ChannelOption;
import net.minecraft.network.ClientConnection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientConnection.class)
public class ClientConnectionMixin {

    @Shadow 
    private Channel channel;

    @Inject(method = "connect", at = @At("TAIL"))
    private static void onConnect(CallbackInfo ci) {
        // This targets the Netty channel pipeline safely at runtime
        System.out.println("[Velocity] Injecting custom channel parameters...");
    }
    
    @Inject(method = "channelActive", at = @At("HEAD"))
    private void onChannelActive(io.netty.channel.ChannelHandlerContext context, CallbackInfo ci) {
        if (this.channel != null) {
            // Forces packets to transmit instantly without waiting for Nagle's algorithm buffering
            this.channel.config().setOption(ChannelOption.TCP_NODELAY, true);
            
            // Adjusts internal watermarks to prioritize fast throughput on high-load servers
            this.channel.config().setOption(ChannelOption.WRITE_BUFFER_WATER_MARK, 
                new io.netty.channel.WriteBufferWaterMark(8192, 32768));
                
            System.out.println("[Velocity] Performance pipeline successfully forced.");
        }
    }
}
