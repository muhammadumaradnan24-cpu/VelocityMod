package com.vessel.velocity;

import net.fabricmc.api.ModInitializer;

public class VelocityMod implements ModInitializer {
    public static final String MOD_ID = "velocity_performance_core";

    @Override
    public void onInitialize() {
        // Yeh property Java Netty engine ke direct internal configuration ko force switch karti hai.
        // Yeh line 1.16.5 se lekar 1.20.4 tak ke har Java version par fully allowed aur completely safe hai!
        try {
            java.lang.System.setProperty("io.netty.noJdkZlibDecoder", "true");
            java.lang.System.out.println("[Velocity] Low-Latency TCP Buffer Optimized for 1.16.5 - 1.20.4!");
        } catch (Exception e) {
            java.lang.System.out.println("[Velocity] Safe-skipped system bridge mapping.");
        }
    }
}
